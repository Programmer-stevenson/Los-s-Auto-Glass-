export { default as authRoutes } from './auth';
export { default as servicesRoutes } from './services';
export { default as bookingsRoutes } from './bookings';
export { default as calendarRoutes } from './calendar';
export { default as paymentsRoutes } from './payments';
export { default as contactRoutes } from './contact';
export { default as adminRoutes } from './admin';
export { default as smsRoutes } from './sms';
